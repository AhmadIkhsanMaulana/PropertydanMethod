<?php 
	//Jualan Pakaian
	//Celana
	//Baju
	class Pakaian {
		public $warna,
			   $ukuran,
			   $bahan,
			   $harga;

		public function getbuy(){
			return "$this->warna,$this->ukuran,
			        $this->bahan,$this->harga";
		}

		
	}

	$celana = new Pakaian();
	$celana->warna = "Navy";
	$celana->ukuran = "L";
	$celana->bahan = "Waterproof";
	$celana->harga = 50000;


	$baju = new Pakaian();
	$baju->warna = "Hijau";
	$baju->ukuran = "XL";
	$baju->bahan = "Katun";
	$baju->harga = 75000;



	echo "Celana : ". $celana->getbuy();
	echo "<br>";
	echo "Baju : ". $baju->getbuy();





 ?>